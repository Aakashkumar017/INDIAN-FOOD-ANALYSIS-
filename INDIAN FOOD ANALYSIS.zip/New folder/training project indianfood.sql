create database indianfood;
use indianfood;

select * from indianfood

UPDATE indianfood
SET state = 'Unknown'
WHERE state = '-1';

UPDATE indianfood
SET flavor_profile = 'Unknown'
WHERE flavor_profile = '-1';


UPDATE indianfood
SET region = 'Unknown'
WHERE region  = '-1';

UPDATE indianfood
SET prep_time= 10
WHERE prep_time  = '-1';


UPDATE indianfood
SET cook_time= 10
WHERE cook_time  = '-1';



